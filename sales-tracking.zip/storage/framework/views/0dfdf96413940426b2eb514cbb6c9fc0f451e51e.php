<!-- Sidebar -->
<div class="sidebar sidebar-style-2">

    <div class="sidebar-wrapper scrollbar scrollbar-inner">
        <div class="sidebar-content">
            <div class="user">
                <div class="avatar-sm float-left mr-2">
                    <img src="<?php echo e(asset('assets/img/profile-sales.jpg')); ?>" alt="Foto Profil"
                        class="avatar-img rounded-circle">
                </div>
                <div class="info">
                    <a data-toggle="collapse" href="#collapseExample" aria-expanded="true">
                        <span>
                            <?php echo e(Auth::user()->nama); ?>

                            <span class="user-level"><?php echo e(Auth::user()->role); ?></span>
                            <span class="caret"></span>
                        </span>
                    </a>
                    <div class="clearfix"></div>
                    <div class="collapse in" id="collapseExample">
                        <ul class="nav">
                            <a href="<?php echo e(route('edit.profil.sales')); ?>">
                                <span class="link-collapse">Edit Profil</span>
                            </a>
                            </li>
                        </ul>
                    </div>
                </div>
            </div>
            <ul class="nav nav-primary">
                <li class="nav-item">
                    <a href="<?php echo e(route('page.sales')); ?>">
                        <i class="fas fa-home"></i>
                        <p>Dashboard</p>
                    </a>
                </li>
                <li class="nav-section">
                    <span class="sidebar-mini-icon">
                        <i class="fa fa-ellipsis-h"></i>
                    </span>
                    <h4 class="text-section">Menu</h4>
                </li>
                <li class="nav-item">
                    <a href="<?php echo e(route('sales.daftar.tugas')); ?>">
                        <i class="fas fa-tasks"></i>
                        <p>Tugas</p>
                    </a>
                </li>
            </ul>
        </div>
    </div>
</div>
<?php /**PATH D:\DATA M. L. HAKIM\GITHUB\sales-tracking\resources\views/sales/Layout/Sidebar.blade.php ENDPATH**/ ?>