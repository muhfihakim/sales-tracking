<?php $__env->startSection('css'); ?>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <div class="main-panel">
        <div class="content">
            <div class="page-inner">
                <div class="page-header">
                    <h4 class="page-title">Sistem Informasi Sales dan Pengiriman</h4>
                </div>
                <div class="row">
                    <div class="col-md-12">
                        <div class="card">
                            <div class="card-header">
                                <h4 class="card-title">Daftar Tugas</h4>
                            </div>
                            <div class="card-body">
                                <?php if(session('success')): ?>
                                    <div class="alert alert-success alert-dismissible fade show" role="alert">
                                        <?php echo e(session('success')); ?>

                                    </div>
                                <?php endif; ?>
                                <?php if(session('error')): ?>
                                    <div class="alert alert-danger alert-dismissible fade show" role="alert">
                                        <?php echo e(session('error')); ?>

                                    </div>
                                <?php endif; ?>
                                <div class="table-responsive">
                                    <table id="basic-datatables" class="display table table-striped table-hover">
                                        <thead>
                                            <tr>
                                                <th>ID Outlet</th>
                                                <th>Outlet</th>
                                                <th>Sales</th>
                                                <th>Tujuan Sales</th>
                                                <th>Deskripsi Tugas</th>
                                                <th>Status</th>
                                                <th>Waktu Penyelesaian</th> <!-- Kolom Baru -->
                                                <th>Action</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            <?php $__currentLoopData = $tasks; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $task): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <tr>
                                                    <td><?php echo e($task->outlet->id); ?></td>
                                                    <td><?php echo e($task->outlet->nama); ?></td>
                                                    <td><?php echo e($task->sales->nama); ?></td>
                                                    <td><?php echo e(excerpt($task->outlet->alamat, 40)); ?></td>
                                                    <td><?php echo e($task->deskripsi); ?></td>
                                                    <td><?php echo e($task->status); ?></td>
                                                    <td>
                                                        <?php if($task->status == 'Selesai' && $task->updated_at): ?>
                                                            <?php echo e($task->updated_at->format('H:i / d-m-Y')); ?>

                                                        <?php else: ?>
                                                            -
                                                        <?php endif; ?>
                                                    </td>
                                                    <td>
                                                        <a href="<?php echo e(route('lacak.sales', $task->id)); ?>"
                                                            class="btn btn-success btn-sm"><i
                                                                class="fas fa-location-arrow"></i> Lacak Sales</a>
                                                        <a href="<?php echo e(route('edit.tugas', $task->id)); ?>"
                                                            class="btn btn-warning btn-sm"><i class="fa fa-edit"></i> Edit
                                                            Tugas</a>
                                                        <!-- Dropdown untuk mengubah status -->
                                                        <div class="dropdown" style="display:inline;">
                                                            <button class="btn btn-secondary dropdown-toggle btn-sm"
                                                                type="button" id="dropdownMenuButton"
                                                                data-toggle="dropdown" aria-haspopup="true"
                                                                aria-expanded="false"> <i class="fas fa-truck"></i> Ubah
                                                                Status
                                                            </button>
                                                            <div class="dropdown-menu" aria-labelledby="dropdownMenuButton">
                                                                <form action="<?php echo e(route('tasks.updateStatus', $task->id)); ?>"
                                                                    method="POST" style="display:inline;">
                                                                    <?php echo csrf_field(); ?>
                                                                    <?php echo method_field('PATCH'); ?>
                                                                    <input type="hidden" name="status" value="Dibatalkan">
                                                                    <button type="submit" class="dropdown-item">Batalkan
                                                                        Tugas</button>
                                                                </form>
                                                                <form action="<?php echo e(route('tasks.updateStatus', $task->id)); ?>"
                                                                    method="POST" style="display:inline;">
                                                                    <?php echo csrf_field(); ?>
                                                                    <?php echo method_field('PATCH'); ?>
                                                                    <input type="hidden" name="status" value="Selesai">
                                                                    <button type="submit" class="dropdown-item">Tandai
                                                                        Selesai</button>
                                                                </form>
                                                            </div>
                                                        </div>
                                                    </td>
                                                </tr>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    </div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('scripts'); ?>
    <script src="<?php echo e(asset('assets/js/plugin/sweetalert/sweetalert.min.js')); ?>"></script>
    <script>
        $(document).ready(function() {
            $('#basic-datatables').DataTable({});
        });
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.Layout.Index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\DATA M. L. HAKIM\GITHUB\sales-management\resources\views/admin/daftarTugas.blade.php ENDPATH**/ ?>