<?php $__env->startSection('css'); ?>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <div class="main-panel">
        <div class="content">
            <div class="page-inner">
                <div class="page-header">
                    <h4 class="page-title">Sistem Informasi Sales dan Pengiriman</h4>
                </div>
                <div class="row">
                    <div class="col-md-12">
                        <div class="card">
                            <div class="card-header">
                                <h4 class="card-title">Edit Sales</h4>
                            </div>
                            <div class="card-body">
                                <div class="row">
                                    <div class="col-md-6 col-lg-4">
                                        <form action="<?php echo e(route('aksi.edit.sales', $sales->id)); ?>" method="POST">
                                            <?php echo csrf_field(); ?>
                                            <?php echo method_field('PUT'); ?>
                                            <div class="form-group">
                                                <label for="nama">Nama Sales</label>
                                                <input type="text" class="form-control" id="nama" name="nama"
                                                    value="<?php echo e($sales->nama); ?>" required>
                                            </div>
                                            <div class="form-group">
                                                <label for="email">Email</label>
                                                <input type="email" class="form-control" id="email" name="email"
                                                    value="<?php echo e($sales->user->email); ?>" required>
                                            </div>
                                            <div class="form-group">
                                                <label for="password">Password</label>
                                                <input type="password" class="form-control" id="password" name="password"
                                                    placeholder="Biarkan kosong jika tidak ingin mengubah password">
                                            </div>
                                            <div class="form-group">
                                                <label for="jenis_kelamin">Jenis Kelamin</label>
                                                <select class="form-control" id="jenis_kelamin" name="jenis_kelamin"
                                                    required>
                                                    <option value="Laki-laki"
                                                        <?php echo e($sales->jenis_kelamin == 'Laki-laki' ? 'selected' : ''); ?>>
                                                        Laki-laki</option>
                                                    <option value="Perempuan"
                                                        <?php echo e($sales->jenis_kelamin == 'Perempuan' ? 'selected' : ''); ?>>
                                                        Perempuan</option>
                                                </select>
                                            </div>
                                            <div class="form-group">
                                                <label for="jenis_kendaraan">Jenis Kendaraan</label>
                                                <select class="form-control" id="jenis_kendaraan" name="jenis_kendaraan"
                                                    required>
                                                    <option value="Motor"
                                                        <?php echo e($sales->jenis_kendaraan == 'Motor' ? 'selected' : ''); ?>>Motor
                                                    </option>
                                                    <option value="Mobil"
                                                        <?php echo e($sales->jenis_kendaraan == 'Mobil' ? 'selected' : ''); ?>>Mobil
                                                    </option>
                                                </select>
                                            </div>
                                            <div class="form-group">
                                                <label for="plat_kendaraan">Plat Kendaraan</label>
                                                <input type="text" class="form-control" id="plat_kendaraan"
                                                    name="plat_kendaraan" value="<?php echo e($sales->plat_kendaraan); ?>" required>
                                            </div>
                                            <a href="<?php echo e(route('daftar.sales')); ?>"
                                                class="btn btn-secondary btn-sm">Kembali</a>
                                            <button type="submit" class="btn btn-primary btn-sm">Simpan</button>
                                        </form>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    </div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('scripts'); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.Layout.Index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\DATA M. L. HAKIM\GITHUB\sales-management\resources\views/admin/EditSales.blade.php ENDPATH**/ ?>