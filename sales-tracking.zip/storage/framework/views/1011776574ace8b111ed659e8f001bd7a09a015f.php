<?php $__env->startSection('css'); ?>
    <style>
        /* Custom CSS for the map */
        #map {
            height: 500px;
            width: 100%;
            border: 0;
        }

        .pulse-icon {
            display: inline-block;
            width: 10px;
            height: 10px;
            background-color: #1269db;
            border-radius: 50%;
            animation: pulse 1s infinite;
        }

        @keyframes pulse {
            0% {
                transform: scale(0.8);
                opacity: 0.7;
            }

            50% {
                transform: scale(1.2);
                opacity: 1;
            }

            100% {
                transform: scale(0.8);
                opacity: 0.7;
            }
        }
    </style>
    <!-- Leaflet CSS -->
    <link rel="stylesheet" href="https://unpkg.com/leaflet@1.7.1/dist/leaflet.css" />
    <!-- Leaflet Routing Machine CSS -->
    <link rel="stylesheet" href="https://unpkg.com/leaflet-routing-machine/dist/leaflet-routing-machine.css" />
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="main-panel">
        <div class="content">
            <div class="page-inner">
                <div class="page-header">
                    <h4 class="page-title">Sistem Informasi Sales dan Pengiriman</h4>
                </div>
                <div class="row">
                    <div class="col-md-12">
                        <div class="card">
                            <div class="card-header">
                                <h4 class="card-title">Peta Lokasi Sales: <?php echo e($task->sales->nama); ?> <span
                                        class="pulse-icon"></span></h4>
                            </div>
                            <div class="card-body">
                                <div id="map"></div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
    <!-- Leaflet JS -->
    <script src="https://unpkg.com/leaflet@1.7.1/dist/leaflet.js"></script>
    <!-- Leaflet Routing Machine JS -->
    <script src="https://unpkg.com/leaflet-routing-machine/dist/leaflet-routing-machine.js"></script>
    <!-- Leaflet Routing Machine dependencies -->
    <script src="https://unpkg.com/leaflet-control-geocoder/dist/Control.Geocoder.js"></script>
    <!-- Turf.js for spatial analysis -->
    <script src="https://unpkg.com/@turf/turf"></script>

    <script>
        // Initialize the map
        var map = L.map('map').setView([-6.200000, 106.816666], 5); // Center the map on Indonesia

        // Add OpenStreetMap tiles
        L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
            maxZoom: 19,
            attribution: '&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors'
        }).addTo(map);

        // Placeholder for multiple waypoints (sales tasks)
        var waypoints = [
            L.latLng(<?php echo e($latestLocation->latitude); ?>, <?php echo e($latestLocation->longitude); ?>), // Start at the latest location
            <?php $__currentLoopData = $salesTasks; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $task): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                L.latLng(<?php echo e($task->outlet->latitude); ?>, <?php echo e($task->outlet->longitude); ?>),
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        ];

        // Add marker for the latest location (blue)
        var latestLocationMarker = L.marker([<?php echo e($latestLocation->latitude); ?>, <?php echo e($latestLocation->longitude); ?>], {
                icon: L.icon({
                    iconUrl: 'https://cdn.rawgit.com/pointhi/leaflet-color-markers/master/img/marker-icon-blue.png',
                    shadowUrl: 'https://cdnjs.cloudflare.com/ajax/libs/leaflet/1.7.1/images/marker-shadow.png',
                    iconSize: [25, 41],
                    iconAnchor: [12, 41],
                    popupAnchor: [1, -34],
                    shadowSize: [41, 41]
                })
            }).addTo(map)
            .bindPopup(
                '<b>Lokasi Terkini</b><br>Latitude: <?php echo e($latestLocation->latitude); ?><br>Longitude: <?php echo e($latestLocation->longitude); ?>'
            )
            .openPopup();

        // Add markers for outlets (red)
        <?php $__currentLoopData = $salesTasks; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $task): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            var outletMarker = L.marker([<?php echo e($task->outlet->latitude); ?>, <?php echo e($task->outlet->longitude); ?>], {
                    icon: L.icon({
                        iconUrl: 'https://cdn.rawgit.com/pointhi/leaflet-color-markers/master/img/marker-icon-red.png',
                        shadowUrl: 'https://cdnjs.cloudflare.com/ajax/libs/leaflet/1.7.1/images/marker-shadow.png',
                        iconSize: [25, 41],
                        iconAnchor: [12, 41],
                        popupAnchor: [1, -34],
                        shadowSize: [41, 41]
                    })
                })
                .addTo(map)
                .bindPopup(
                    '<b>Lokasi Outlet</b><br>Nama Outlet: <?php echo e($task->outlet->name); ?><br>Latitude: <?php echo e($task->outlet->latitude); ?><br>Longitude: <?php echo e($task->outlet->longitude); ?>'
                );
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

        // Add routing control to show the route and directions
        L.Routing.control({
            waypoints: waypoints,
            routeWhileDragging: false,
            geocoder: L.Control.Geocoder.nominatim(),
            lineOptions: {
                styles: [{
                    color: 'blue',
                    opacity: 1,
                    weight: 5
                }]
            }
        }).addTo(map);

        // Add geofence as a circle around the latest location and each outlet
        function addGeofence(lat, lng, radius, color) {
            return L.circle([lat, lng], {
                color: color,
                fillColor: color,
                fillOpacity: 0.2,
                radius: radius // Radius in meters
            }).addTo(map);
        }

        // Example: Add geofence with 1000 meter radius around latest location and each outlet
        var geofenceRadius = 1000; // 1000 meters
        addGeofence(<?php echo e($latestLocation->latitude); ?>, <?php echo e($latestLocation->longitude); ?>, geofenceRadius, 'green');

        <?php $__currentLoopData = $salesTasks; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $task): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            addGeofence(<?php echo e($task->outlet->latitude); ?>, <?php echo e($task->outlet->longitude); ?>, geofenceRadius, 'red');
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.Layout.Index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\DATA M. L. HAKIM\GITHUB\sales-management\resources\views/admin/LacakSales.blade.php ENDPATH**/ ?>