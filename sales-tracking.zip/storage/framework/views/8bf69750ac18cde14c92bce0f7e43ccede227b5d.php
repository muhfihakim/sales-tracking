<?php $__env->startSection('content'); ?>
    <div class="row">
        <div class="col-md-12">
            <h2>Daftar Tugas</h2>
            <table id="tasks-table" class="table table-striped table-bordered">
                <thead>
                    <tr>
                        <th>Outlet</th>
                        <th>Alamat Outlet</th>
                        <th>Deskripsi Tugas</th>
                        <th>Status</th>
                        <th>Jarak (km)</th>
                        <th>Action</th>
                    </tr>
                </thead>
                <tbody>
                    <?php $__currentLoopData = $tasks; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $task): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td><?php echo e($task->outlet->nama); ?></td>
                            <td><?php echo e($task->outlet->alamat); ?></td>
                            <td><?php echo e($task->deskripsi); ?></td>
                            <td><?php echo e($task->status); ?></td>
                            <td><?php echo e($task->distance ? number_format($task->distance, 2) : 'N/A'); ?></td>
                            <td>
                                <?php if($task->status == 'Selesai'): ?>
                                    <span class="badge badge-success">Diselesaikan</span>
                                <?php else: ?>
                                    <?php if($task->distance && $task->distance <= 1): ?>
                                        <form action="<?php echo e(route('tugas.sales.selesai', $task->id)); ?>" method="POST"
                                            style="margin-top: 5px;">
                                            <?php echo csrf_field(); ?>
                                            <?php echo method_field('PUT'); ?>
                                            <button type="submit" class="btn btn-danger">Selesaikan</button>
                                        </form>
                                    <?php else: ?>
                                        <span class="badge badge-secondary">Anda Diluar Jangkauan</span>
                                    <?php endif; ?>
                                <?php endif; ?>
                            </td>
                        </tr>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                </tbody>
            </table>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>
    <script>
        $(document).ready(function() {
            $('#tasks-table').DataTable();
        });
    </script>
    <script>
        // Set interval to send location every 10 seconds
        setInterval(() => {
            if (navigator.geolocation) {
                navigator.geolocation.getCurrentPosition(position => {
                    const lat = position.coords.latitude;
                    const lng = position.coords.longitude;

                    document.getElementById('status').innerText = `Latitude: ${lat}, Longitude: ${lng}`;

                    // Send location to the server
                    fetch('<?php echo e(route('sales.update.location')); ?>', {
                            method: 'POST',
                            headers: {
                                'Content-Type': 'application/json',
                                'X-CSRF-TOKEN': document.querySelector('meta[name="csrf-token"]')
                                    .getAttribute('content')
                            },
                            body: JSON.stringify({
                                sales_id: '<?php echo e(auth()->user()->id); ?>',
                                latitude: lat,
                                longitude: lng
                            })
                        })
                        .then(response => response.json())
                        .then(data => {
                            if (data.status === 'success') {
                                console.log('Location updated successfully');
                            } else {
                                console.error('Failed to update location', data);
                            }
                        })
                        .catch(error => console.error('Error:', error));
                }, error => {
                    console.error(error);
                });
            } else {
                document.getElementById('status').innerText = 'Geolocation is not supported by this browser.';
            }
        }, 5000);
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('sales.index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\DATA M. L. HAKIM\GITHUB\sales-management\resources\views/sales/DaftarTugas.blade.php ENDPATH**/ ?>