<?php $__env->startSection('content'); ?>
    <div class="row">
        <div class="col-md-12">
            <h2>Tambah Tugas</h2>
            <form method="POST" action="<?php echo e(route('aksi.tambah.tugas')); ?>">
                <?php echo csrf_field(); ?>
                <div class="form-group">
                    <label for="sales_id">Sales yang Ditugaskan</label>
                    <select class="form-control" id="sales_id" name="sales_id" required>
                        <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php if($user->role == 'Sales'): ?>
                                <!-- Pastikan hanya menampilkan Sales -->
                                <option value="<?php echo e($user->id); ?>"><?php echo e($user->name); ?></option>
                            <?php endif; ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                </div>
                <div class="form-group">
                    <label for="outlet_id">Tujuan Outlet</label>
                    <select class="form-control" id="outlet_id" name="outlet_id" required>
                        <?php $__currentLoopData = $outlets; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $outlet): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($outlet->id); ?>"><?php echo e($outlet->nama); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                </div>
                <div class="form-group">
                    <label for="deskripsi">Deskripsi Tugas</label>
                    <textarea class="form-control" id="deskripsi" name="deskripsi" rows="3" required></textarea>
                </div>
                <button type="submit" class="btn btn-success">Tambah Tugas</button>
            </form>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\DATA M. L. HAKIM\GITHUB\sales-management\resources\views/admin/TambahTugas.blade.php ENDPATH**/ ?>