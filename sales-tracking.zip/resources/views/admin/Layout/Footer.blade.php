   <footer class="footer">
       <div class="container-fluid">
           <div class="copyright ml-auto">
               2024, made with <i class="fa fa-heart heart text-danger"></i> by <a href="https://mybbs.id">BBS-Web
                   Developer</a>
           </div>
       </div>
   </footer>
   </div>
